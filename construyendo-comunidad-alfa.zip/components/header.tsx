"use client"
import { useState, useEffect } from "react"
import type React from "react"

import Image from "next/image"
import Link from "next/link"
import { Menu, X } from "lucide-react"

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setIsScrolled(true)
      } else {
        setIsScrolled(false)
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => {
      window.removeEventListener("scroll", handleScroll)
    }
  }, [])

  return (
    <header
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
        isScrolled ? "bg-white shadow-md py-2" : "bg-transparent py-4"
      }`}
    >
      <div className="container mx-auto px-4 flex justify-between items-center">
        <div className="flex items-center">
          <Link href="/">
            <Image
              src="/logo.svg"
              alt="Instituto Bahá'í Logo"
              width={60}
              height={60}
              className="transition-transform duration-300 hover:scale-110"
            />
          </Link>
          <div className="ml-4 hidden md:block">
            <h1 className="text-xl font-bold text-gray-800">INSTITUTO BAHÁ&apos;Í</h1>
            <p className="text-sm text-gray-600">CAPACITACIÓN Y DESARROLLO COMUNITARIO</p>
            <p className="text-lg font-semibold text-gray-700">ISLAS CANARIAS</p>
          </div>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-6">
          <NavLink href="#inicio">Inicio</NavLink>
          <NavLink href="#quienes-somos">Quiénes Somos</NavLink>
          <NavLink href="#programas">Programas</NavLink>
          <NavLink href="#contacto">Contacto</NavLink>
          <button className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-full transition-colors duration-300">
            Participar
          </button>
        </nav>

        {/* Mobile Menu Button */}
        <button className="md:hidden text-gray-800" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
          {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Navigation */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white shadow-lg absolute top-full left-0 w-full py-4 px-4 transition-all duration-300">
          <div className="flex flex-col space-y-4">
            <MobileNavLink href="#inicio" onClick={() => setMobileMenuOpen(false)}>
              Inicio
            </MobileNavLink>
            <MobileNavLink href="#quienes-somos" onClick={() => setMobileMenuOpen(false)}>
              Quiénes Somos
            </MobileNavLink>
            <MobileNavLink href="#programas" onClick={() => setMobileMenuOpen(false)}>
              Programas
            </MobileNavLink>
            <MobileNavLink href="#contacto" onClick={() => setMobileMenuOpen(false)}>
              Contacto
            </MobileNavLink>
            <button className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-full transition-colors duration-300 w-full">
              Participar
            </button>
          </div>
        </div>
      )}
    </header>
  )
}

const NavLink = ({ href, children }: { href: string; children: React.ReactNode }) => {
  return (
    <Link href={href} className="text-gray-700 hover:text-blue-500 font-medium transition-colors duration-300">
      {children}
    </Link>
  )
}

const MobileNavLink = ({
  href,
  onClick,
  children,
}: {
  href: string
  onClick: () => void
  children: React.ReactNode
}) => {
  return (
    <Link
      href={href}
      className="text-gray-700 hover:text-blue-500 font-medium transition-colors duration-300 block py-2"
      onClick={onClick}
    >
      {children}
    </Link>
  )
}

export default Header

