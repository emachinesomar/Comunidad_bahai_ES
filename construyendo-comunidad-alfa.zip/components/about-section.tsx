import Image from "next/image"

const AboutSection = () => {
  return (
    <section id="quienes-somos" className="bg-blue-500 py-16 md:py-24">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12" data-aos="fade-up">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Quiénes Somos</h2>
          <div className="w-24 h-1 bg-yellow-400 mx-auto"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div data-aos="fade-right" data-aos-delay="200">
            <Image
              src="/placeholder.svg?height=400&width=600"
              alt="Actividades comunitarias"
              width={600}
              height={400}
              className="rounded-lg shadow-xl"
            />
          </div>
          <div data-aos="fade-left" data-aos-delay="300">
            <h3 className="text-2xl font-bold text-white mb-4">Instituto Bahá&apos;í de Capacitación</h3>
            <p className="text-white text-lg mb-6">
              El Instituto Bahá&apos;í de las Islas Canarias es una institución educativa dedicada a la capacitación de
              recursos humanos para el desarrollo comunitario. Nuestro enfoque se basa en el empoderamiento de
              individuos y comunidades para que sean protagonistas de su propio desarrollo.
            </p>
            <p className="text-white text-lg mb-6">
              Trabajamos con personas de todas las edades y orígenes, promoviendo valores como la unidad, la justicia y
              la igualdad. Nuestros programas están diseñados para fortalecer las capacidades de servicio a la comunidad
              y fomentar un proceso de transformación individual y colectiva.
            </p>
            <button className="bg-white text-blue-600 hover:bg-blue-100 px-6 py-3 rounded-full font-medium transition-all duration-300 transform hover:scale-105">
              Conoce Nuestra Historia
            </button>
          </div>
        </div>
      </div>
    </section>
  )
}

export default AboutSection

