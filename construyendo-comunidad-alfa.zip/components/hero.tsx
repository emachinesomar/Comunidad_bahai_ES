import Image from "next/image"

const Hero = () => {
  return (
    <section id="inicio" className="relative h-screen w-full overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <Image
          src="https://sjc.microlink.io/wXF2c0-fqZiNAetDgmkHGjIU0Wn3Tig2VTWvXznorDqJiV9iShQzFfMuL5SW2o_V0oqSK4HtM6Pv314CF1ObLQ.jpeg"
          alt="Niño participando en actividades comunitarias"
          fill
          priority
          className="object-cover"
        />
        <div className="absolute inset-0 bg-black bg-opacity-30"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 h-full flex flex-col items-center justify-center text-center px-4">
        <div className="mt-20 md:mt-0" data-aos="fade-up" data-aos-delay="200">
          <Image src="/logo.svg" alt="Instituto Bahá'í Logo" width={120} height={120} className="mx-auto mb-6" />
          <h1 className="text-white text-3xl md:text-4xl lg:text-5xl font-bold mb-2">INSTITUTO BAHÁ&apos;Í</h1>
          <p className="text-white text-lg md:text-xl mb-2">CAPACITACIÓN Y DESARROLLO COMUNITARIO</p>
          <h2 className="text-white text-2xl md:text-3xl font-semibold mb-8">ISLAS CANARIAS</h2>
        </div>

        <div className="mt-8" data-aos="fade-up" data-aos-delay="400">
          <div className="text-center">
            <h2 className="text-4xl md:text-5xl font-bold">
              <span className="text-green-500">CONSTRUYENDO</span>
              <br />
              <span className="text-yellow-500">COMUNIDAD</span>
              <br />
              <span className="text-blue-400 font-script text-3xl md:text-4xl">en familia</span>
            </h2>
          </div>
        </div>

        <div className="mt-12" data-aos="fade-up" data-aos-delay="600">
          <button className="bg-blue-500 hover:bg-blue-600 text-white px-8 py-3 rounded-full text-lg font-medium transition-all duration-300 transform hover:scale-105">
            Conoce Nuestros Programas
          </button>
        </div>
      </div>
    </section>
  )
}

export default Hero

