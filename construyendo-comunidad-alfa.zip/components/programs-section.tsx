import { Check } from "lucide-react"

const ProgramsSection = () => {
  const programs = [
    {
      title: "Clases de Niños",
      description: "Desarrollo de cualidades espirituales y valores morales en niños de 5 a 11 años.",
      image: "/placeholder.svg?height=300&width=400",
      features: [
        "Actividades lúdicas y artísticas",
        "Desarrollo de virtudes y valores",
        "Servicio a la comunidad",
        "Fortalecimiento de la identidad positiva",
      ],
    },
    {
      title: "Grupos Prejuveniles",
      description: "Empoderamiento de prejóvenes de 12 a 14 años para ser agentes de cambio positivo.",
      image: "/placeholder.svg?height=300&width=400",
      features: [
        "Desarrollo de capacidades de servicio",
        "Fortalecimiento del carácter",
        "Análisis crítico de la sociedad",
        "Proyectos de servicio comunitario",
      ],
    },
    {
      title: "Círculos de Estudio",
      description: "Espacios de aprendizaje colaborativo para jóvenes y adultos.",
      image: "/placeholder.svg?height=300&width=400",
      features: [
        "Estudio de conceptos sobre desarrollo comunitario",
        "Adquisición de habilidades prácticas",
        "Aplicación en proyectos comunitarios",
        "Acompañamiento a iniciativas locales",
      ],
    },
  ]

  return (
    <section id="programas" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16" data-aos="fade-up">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">Nuestros Programas</h2>
          <div className="w-24 h-1 bg-blue-500 mx-auto mb-6"></div>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Ofrecemos diversos programas educativos para todas las edades, orientados al desarrollo de capacidades para
            el servicio a la comunidad.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
          {programs.map((program, index) => (
            <div
              key={index}
              className="bg-white rounded-lg shadow-lg overflow-hidden transform transition-all duration-300 hover:-translate-y-2 hover:shadow-xl"
              data-aos="fade-up"
              data-aos-delay={200 + index * 100}
            >
              <div className="h-48 overflow-hidden">
                <img
                  src={program.image || "/placeholder.svg"}
                  alt={program.title}
                  className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-800 mb-3">{program.title}</h3>
                <p className="text-gray-600 mb-4">{program.description}</p>
                <ul className="space-y-2 mb-6">
                  {program.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start">
                      <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
                      <span className="text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>
                <button className="w-full bg-blue-500 hover:bg-blue-600 text-white py-2 rounded-full transition-colors duration-300">
                  Más Información
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-16" data-aos="fade-up">
          <button className="bg-yellow-500 hover:bg-yellow-600 text-white px-8 py-3 rounded-full text-lg font-medium transition-all duration-300 transform hover:scale-105">
            Ver Todos los Programas
          </button>
        </div>
      </div>
    </section>
  )
}

export default ProgramsSection

