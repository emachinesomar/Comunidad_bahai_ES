"use client"
import { useEffect } from "react"
import Header from "@/components/header"
import Hero from "@/components/hero"
import WaveSection from "@/components/wave-section"
import AboutSection from "@/components/about-section"
import ProgramsSection from "@/components/programs-section"
import ContactSection from "@/components/contact-section"
import Footer from "@/components/footer"
import AOS from "aos"

export default function Home() {
  useEffect(() => {
    // Initialize AOS animation library
    AOS.init({
      duration: 800,
      easing: "ease-in-out",
      once: false,
    })
  }, [])

  return (
    <main className="min-h-screen overflow-x-hidden">
      <Header />
      <Hero />
      <WaveSection />
      <AboutSection />
      <ProgramsSection />
      <ContactSection />
      <Footer />
    </main>
  )
}

